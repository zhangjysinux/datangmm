/*
 * Copyright 1992 by Jutta Degener and Carsten Bormann, Technische
 * Universitaet Berlin.  See the accompanying file "COPYRIGHT" for
 * details.  THERE IS ABSOLUTELY NO WARRANTY FOR THIS SOFTWARE.
 */
 
/*
 * common code to sweet.c and bitter.c
 */

#ifndef	TASTE_H
#define	TASTE_H

struct spex {

	char	* var;
	int	varsize;
} ;

#endif	/* TASTE_H */
